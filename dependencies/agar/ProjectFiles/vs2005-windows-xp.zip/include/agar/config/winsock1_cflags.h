#ifndef WINSOCK1_CFLAGS
#define WINSOCK1_CFLAGS ""
#endif
