#ifndef GLX_CFLAGS
#define GLX_CFLAGS ""
#endif
