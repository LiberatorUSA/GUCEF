#ifndef HAVE_CLOCK
#define HAVE_CLOCK "yes"
#endif
