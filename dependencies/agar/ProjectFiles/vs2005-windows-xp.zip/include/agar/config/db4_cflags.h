#ifndef DB4_CFLAGS
#define DB4_CFLAGS ""
#endif
