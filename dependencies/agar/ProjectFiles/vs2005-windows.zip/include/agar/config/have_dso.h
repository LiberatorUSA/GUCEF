#undef HAVE_DSO
