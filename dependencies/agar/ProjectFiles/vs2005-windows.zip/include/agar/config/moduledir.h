#ifndef MODULEDIR
#define MODULEDIR "/usr/local/lib"
#endif
