#ifndef KQUEUE_LIBS
#define KQUEUE_LIBS ""
#endif
