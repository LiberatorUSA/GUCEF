#ifndef HAVE_MATH
#define HAVE_MATH "yes"
#endif
