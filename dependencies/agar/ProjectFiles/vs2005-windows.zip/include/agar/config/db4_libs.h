#ifndef DB4_LIBS
#define DB4_LIBS ""
#endif
