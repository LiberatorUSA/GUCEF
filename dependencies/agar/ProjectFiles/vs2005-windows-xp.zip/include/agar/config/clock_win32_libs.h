#ifndef CLOCK_WIN32_LIBS
#define CLOCK_WIN32_LIBS "winmm"
#endif
