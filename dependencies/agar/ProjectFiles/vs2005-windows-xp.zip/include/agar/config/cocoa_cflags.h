#ifndef COCOA_CFLAGS
#define COCOA_CFLAGS ""
#endif
