#ifndef LIBDIR
#define LIBDIR "/usr/local/lib"
#endif
