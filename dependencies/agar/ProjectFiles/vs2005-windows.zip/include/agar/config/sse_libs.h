#ifndef SSE_LIBS
#define SSE_LIBS ""
#endif
