#ifndef LOCALEDIR
#define LOCALEDIR "NONE"
#endif
