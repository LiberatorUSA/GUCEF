#ifndef TTFDIR
#define TTFDIR "NONE"
#endif
