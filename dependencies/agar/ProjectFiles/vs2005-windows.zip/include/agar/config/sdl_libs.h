#ifndef SDL_LIBS
#define SDL_LIBS "SDL"
#endif
