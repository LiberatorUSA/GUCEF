#ifndef JPEG_CFLAGS
#define JPEG_CFLAGS ""
#endif
