#ifndef GLX_LIBS
#define GLX_LIBS ""
#endif
