#ifndef XINERAMA_LIBS
#define XINERAMA_LIBS ""
#endif
