#ifndef SNDFILE_CFLAGS
#define SNDFILE_CFLAGS ""
#endif
