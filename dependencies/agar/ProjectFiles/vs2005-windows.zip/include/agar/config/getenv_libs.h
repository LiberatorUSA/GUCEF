#ifndef GETENV_LIBS
#define GETENV_LIBS ""
#endif
