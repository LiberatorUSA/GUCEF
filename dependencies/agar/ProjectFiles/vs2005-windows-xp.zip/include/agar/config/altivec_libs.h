#ifndef ALTIVEC_LIBS
#define ALTIVEC_LIBS ""
#endif
