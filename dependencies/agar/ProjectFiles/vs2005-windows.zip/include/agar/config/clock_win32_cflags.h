#ifndef CLOCK_WIN32_CFLAGS
#define CLOCK_WIN32_CFLAGS ""
#endif
