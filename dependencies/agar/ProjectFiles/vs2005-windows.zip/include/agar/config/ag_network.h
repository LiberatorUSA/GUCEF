#ifndef AG_NETWORK
#define AG_NETWORK "yes"
#endif
