#ifndef COCOA_LIBS
#define COCOA_LIBS ""
#endif
