#undef HAVE_CSIDL
