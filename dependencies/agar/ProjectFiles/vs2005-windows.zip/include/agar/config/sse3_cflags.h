#ifndef SSE3_CFLAGS
#define SSE3_CFLAGS ""
#endif
