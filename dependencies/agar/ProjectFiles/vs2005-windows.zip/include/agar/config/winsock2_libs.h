#ifndef WINSOCK2_LIBS
#define WINSOCK2_LIBS ""
#endif
