#ifndef SNDFILE_LIBS
#define SNDFILE_LIBS ""
#endif
