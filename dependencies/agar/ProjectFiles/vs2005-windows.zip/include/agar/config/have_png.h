#undef HAVE_PNG
