#ifndef GETENV_CFLAGS
#define GETENV_CFLAGS ""
#endif
