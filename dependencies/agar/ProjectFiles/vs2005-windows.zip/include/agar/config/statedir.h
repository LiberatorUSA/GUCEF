#ifndef STATEDIR
#define STATEDIR "/usr/local/var"
#endif
