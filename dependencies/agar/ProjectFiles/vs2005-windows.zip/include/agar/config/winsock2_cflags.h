#ifndef WINSOCK2_CFLAGS
#define WINSOCK2_CFLAGS ""
#endif
