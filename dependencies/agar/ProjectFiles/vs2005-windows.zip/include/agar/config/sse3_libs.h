#ifndef SSE3_LIBS
#define SSE3_LIBS ""
#endif
