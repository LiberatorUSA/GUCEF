#ifndef PNG_LIBS
#define PNG_LIBS ""
#endif
