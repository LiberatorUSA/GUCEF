#ifndef PNG_CFLAGS
#define PNG_CFLAGS ""
#endif
