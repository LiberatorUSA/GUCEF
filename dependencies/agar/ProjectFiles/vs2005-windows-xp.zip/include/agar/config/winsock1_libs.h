#ifndef WINSOCK1_LIBS
#define WINSOCK1_LIBS "wsock32"
#endif
