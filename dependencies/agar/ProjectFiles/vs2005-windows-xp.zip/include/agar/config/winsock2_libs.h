#ifndef WINSOCK2_LIBS
#define WINSOCK2_LIBS "ws2_32 iphlpapi"
#endif
