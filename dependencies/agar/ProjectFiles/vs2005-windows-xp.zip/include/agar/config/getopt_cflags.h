#ifndef GETOPT_CFLAGS
#define GETOPT_CFLAGS ""
#endif
