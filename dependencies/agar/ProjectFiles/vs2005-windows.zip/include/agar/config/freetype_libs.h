#ifndef FREETYPE_LIBS
#define FREETYPE_LIBS "freetype"
#endif
