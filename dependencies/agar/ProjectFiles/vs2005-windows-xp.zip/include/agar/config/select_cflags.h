#ifndef SELECT_CFLAGS
#define SELECT_CFLAGS ""
#endif
