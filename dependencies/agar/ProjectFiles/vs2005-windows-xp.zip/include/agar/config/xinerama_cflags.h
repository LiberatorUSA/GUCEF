#ifndef XINERAMA_CFLAGS
#define XINERAMA_CFLAGS ""
#endif
