#ifndef SSE2_CFLAGS
#define SSE2_CFLAGS ""
#endif
