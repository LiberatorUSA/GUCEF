#ifndef FONTCONFIG_LIBS
#define FONTCONFIG_LIBS ""
#endif
