#ifndef _MK_LITTLE_ENDIAN
#define _MK_LITTLE_ENDIAN "yes"
#endif
