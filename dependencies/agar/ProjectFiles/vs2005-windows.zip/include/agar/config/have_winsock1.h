#ifndef HAVE_WINSOCK1
#define HAVE_WINSOCK1 "yes"
#endif
