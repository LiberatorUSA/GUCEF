#ifndef GETOPT_LIBS
#define GETOPT_LIBS ""
#endif
