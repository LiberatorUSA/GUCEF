#ifndef CLOCK_LIBS
#define CLOCK_LIBS "winmm"
#endif
