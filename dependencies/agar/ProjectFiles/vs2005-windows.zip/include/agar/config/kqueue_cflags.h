#ifndef KQUEUE_CFLAGS
#define KQUEUE_CFLAGS ""
#endif
