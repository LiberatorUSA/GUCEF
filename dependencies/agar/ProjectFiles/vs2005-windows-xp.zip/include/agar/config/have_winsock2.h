#ifndef HAVE_WINSOCK2
#define HAVE_WINSOCK2 "yes"
#endif
