#ifndef GETADDRINFO_LIBS
#define GETADDRINFO_LIBS ""
#endif
