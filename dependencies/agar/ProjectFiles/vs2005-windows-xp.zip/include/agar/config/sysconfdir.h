#ifndef SYSCONFDIR
#define SYSCONFDIR "/usr/local/etc"
#endif
