#ifndef SSE2_LIBS
#define SSE2_LIBS ""
#endif
