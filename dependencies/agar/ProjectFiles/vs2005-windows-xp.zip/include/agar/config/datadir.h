#ifndef DATADIR
#define DATADIR "NONE"
#endif
