#ifndef SELECT_LIBS
#define SELECT_LIBS ""
#endif
